Before you submit an issue, please review the project's [Support Options](https://ossec.github.io/about.html#support-options).
